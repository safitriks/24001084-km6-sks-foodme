package com.example.foodme.data.model

data class User(
    val fullName: String,
    val email: String
)