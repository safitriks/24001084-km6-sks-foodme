package com.example.foodme.data.model

import java.util.UUID

data class Category(
    var imgUrl: String,
    var name: String
)