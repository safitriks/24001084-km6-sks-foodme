package com.example.foodme.utils

interface ViewHolderBinder <T> {
    fun bind(item : T)
}