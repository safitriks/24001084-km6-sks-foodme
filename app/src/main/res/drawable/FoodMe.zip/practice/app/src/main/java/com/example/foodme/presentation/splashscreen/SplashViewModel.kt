package com.example.foodme.presentation.splashscreen

import androidx.lifecycle.ViewModel
import com.example.foodme.data.repository.UserRepository

class SplashViewModel (private val repository: UserRepository) : ViewModel() {

}