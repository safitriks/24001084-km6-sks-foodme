package com.example.foodme.data.model

data class Profile(
    val name: String,
    val username: String,
    val email: String,
    val profileImg: String
)
