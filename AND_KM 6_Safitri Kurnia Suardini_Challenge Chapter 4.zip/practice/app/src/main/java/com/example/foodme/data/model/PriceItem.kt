package com.example.foodme.data.model

data class PriceItem(
    val name: String,
    val total: Double
)
